# Single-Image-Haze-Removal-Using-Dark-Channel-Prior
《Single Image Haze Removal Using Dark Channel Prior》 论文的 python实现。

更详细的内容可参考[博客](http://blkstone.github.io/2015/08/20/single-image-haze-removal-using-dark-channel/)
